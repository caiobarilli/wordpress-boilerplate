<?php
/**
 * @license BSD-3-Clause
 *
 * Modified by AxePress Development using {@see https://github.com/BrianHenryIE/strauss}.
 */

namespace WPGraphQL\Login\Vendor\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
